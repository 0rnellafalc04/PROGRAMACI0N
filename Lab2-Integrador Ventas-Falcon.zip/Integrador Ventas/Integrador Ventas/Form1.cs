﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Integrador_Ventas
{
    public partial class Form1 : Form
    {
        string tipoPrenda;
        Boolean corto;
        Boolean calidadPremium;
        float precio;
        Int32 canti;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            corto = false;
            Bermuda.Enabled = true;
            mangaCorta.Enabled = false;
            tipoPrenda = "Pantalon";
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            corto = false;
            Bermuda.Enabled = false;
            mangaCorta.Enabled = true;
            tipoPrenda = "Camisa";

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void Bermuda_CheckedChanged(object sender, EventArgs e)
        {
            if (corto)
            {
                corto = false;
            }
            else
            {
                corto = true;
            }
            
        }

        private void mangaCorta_CheckedChanged(object sender, EventArgs e)
        {
            if (corto)
            {
                corto = false;
            }
            else
            {
                corto = true;
            }
        }

        private void premium_CheckedChanged_1(object sender, EventArgs e)
        {
            calidadPremium = true;
        }

        private void standard_CheckedChanged(object sender, EventArgs e)
        {
            calidadPremium = false;
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string texto = pValue.Text;
            if(texto != "")
            {
                precio = float.Parse((string)texto);
            }
            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // If you want, you can allow decimal (float) numbers
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(cValue.Value == 0 || precio == 0 || tipoPrenda == "")
            {
                MessageBox.Show("No has agregado correctamente los datos");
            }
            else
            {
                if (tipoPrenda == "Camisa" && corto)
                {
                    double reduccion = (precio * 0.10);
                    precio = ((float)((float)precio - reduccion));
                }
                else if (tipoPrenda == "Pantalon" && corto)
                {
                    double reduccion = (precio * 0.20);
                    precio = ((float)((float)precio - reduccion));
                }

                if (calidadPremium)
                {
                    double aumento = (precio * 0.30);
                    precio = ((float)((float)precio + aumento));
                }
                precio = precio * (float)cValue.Value;
                MessageBox.Show("El precio final es: " + precio.ToString());

                resetPrecio();
            }
        }
        private void resetPrecio()
        {
            string texto = pValue.Text;
            if (texto != "")
            {
                precio = float.Parse((string)texto);
            }
        }

    }
}


﻿
namespace Integrador_Ventas
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Bermuda = new System.Windows.Forms.CheckBox();
            this.mangaCorta = new System.Windows.Forms.CheckBox();
            this.pantalon = new System.Windows.Forms.RadioButton();
            this.camisa = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.premium = new System.Windows.Forms.RadioButton();
            this.standard = new System.Windows.Forms.RadioButton();
            this.Precio = new System.Windows.Forms.GroupBox();
            this.pValue = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cValue = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.Precio.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cValue)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(72, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "VENTAS POR MAYOR";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Bermuda);
            this.groupBox1.Controls.Add(this.mangaCorta);
            this.groupBox1.Controls.Add(this.pantalon);
            this.groupBox1.Controls.Add(this.camisa);
            this.groupBox1.Location = new System.Drawing.Point(36, 76);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(258, 100);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tipo de prenda";
            // 
            // Bermuda
            // 
            this.Bermuda.AutoSize = true;
            this.Bermuda.Location = new System.Drawing.Point(154, 58);
            this.Bermuda.Name = "Bermuda";
            this.Bermuda.Size = new System.Drawing.Size(74, 19);
            this.Bermuda.TabIndex = 3;
            this.Bermuda.Text = "Bermuda";
            this.Bermuda.UseVisualStyleBackColor = true;
            this.Bermuda.CheckedChanged += new System.EventHandler(this.Bermuda_CheckedChanged);
            // 
            // mangaCorta
            // 
            this.mangaCorta.AutoSize = true;
            this.mangaCorta.Location = new System.Drawing.Point(154, 21);
            this.mangaCorta.Name = "mangaCorta";
            this.mangaCorta.Size = new System.Drawing.Size(93, 19);
            this.mangaCorta.TabIndex = 2;
            this.mangaCorta.Text = "Manga corta";
            this.mangaCorta.UseVisualStyleBackColor = true;
            this.mangaCorta.CheckedChanged += new System.EventHandler(this.mangaCorta_CheckedChanged);
            // 
            // pantalon
            // 
            this.pantalon.AutoSize = true;
            this.pantalon.Location = new System.Drawing.Point(23, 58);
            this.pantalon.Name = "pantalon";
            this.pantalon.Size = new System.Drawing.Size(72, 19);
            this.pantalon.TabIndex = 1;
            this.pantalon.TabStop = true;
            this.pantalon.Text = "Pantalon";
            this.pantalon.UseVisualStyleBackColor = true;
            this.pantalon.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // camisa
            // 
            this.camisa.AutoSize = true;
            this.camisa.Location = new System.Drawing.Point(23, 22);
            this.camisa.Name = "camisa";
            this.camisa.Size = new System.Drawing.Size(64, 19);
            this.camisa.TabIndex = 0;
            this.camisa.TabStop = true;
            this.camisa.Text = "Camisa";
            this.camisa.UseVisualStyleBackColor = true;
            this.camisa.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.premium);
            this.groupBox2.Controls.Add(this.standard);
            this.groupBox2.Location = new System.Drawing.Point(36, 197);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(258, 62);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Calidad de prenda";
            // 
            // premium
            // 
            this.premium.AutoSize = true;
            this.premium.Location = new System.Drawing.Point(134, 22);
            this.premium.Name = "premium";
            this.premium.Size = new System.Drawing.Size(74, 19);
            this.premium.TabIndex = 1;
            this.premium.TabStop = true;
            this.premium.Text = "Premium";
            this.premium.UseVisualStyleBackColor = true;
            this.premium.CheckedChanged += new System.EventHandler(this.premium_CheckedChanged_1);
            // 
            // standard
            // 
            this.standard.AutoSize = true;
            this.standard.Location = new System.Drawing.Point(23, 23);
            this.standard.Name = "standard";
            this.standard.Size = new System.Drawing.Size(72, 19);
            this.standard.TabIndex = 0;
            this.standard.TabStop = true;
            this.standard.Text = "Standard";
            this.standard.UseVisualStyleBackColor = true;
            this.standard.CheckedChanged += new System.EventHandler(this.standard_CheckedChanged);
            // 
            // Precio
            // 
            this.Precio.Controls.Add(this.pValue);
            this.Precio.Location = new System.Drawing.Point(36, 265);
            this.Precio.Name = "Precio";
            this.Precio.Size = new System.Drawing.Size(128, 53);
            this.Precio.TabIndex = 4;
            this.Precio.TabStop = false;
            this.Precio.Text = "Precio";
            this.Precio.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // pValue
            // 
            this.pValue.Location = new System.Drawing.Point(6, 22);
            this.pValue.Name = "pValue";
            this.pValue.Size = new System.Drawing.Size(100, 23);
            this.pValue.TabIndex = 0;
            this.pValue.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.pValue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.cValue);
            this.groupBox4.Location = new System.Drawing.Point(170, 265);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(124, 53);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Cantidad";
            // 
            // cValue
            // 
            this.cValue.Location = new System.Drawing.Point(6, 22);
            this.cValue.Name = "cValue";
            this.cValue.Size = new System.Drawing.Size(71, 23);
            this.cValue.TabIndex = 6;
            this.cValue.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.GreenYellow;
            this.button1.Location = new System.Drawing.Point(36, 336);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(258, 49);
            this.button1.TabIndex = 6;
            this.button1.Text = "CALCULAR PRECIO FINAL";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.Precio);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.Precio.ResumeLayout(false);
            this.Precio.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cValue)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton pantalon;
        private System.Windows.Forms.RadioButton camisa;
        private System.Windows.Forms.CheckBox Bermuda;
        private System.Windows.Forms.CheckBox mangaCorta;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton premium;
        private System.Windows.Forms.RadioButton standard;
        private System.Windows.Forms.GroupBox Precio;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox pValue;
        private System.Windows.Forms.NumericUpDown cValue;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.NumericUpDown cantidad;
    }
}


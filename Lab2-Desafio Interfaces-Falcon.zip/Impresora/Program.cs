﻿using System;
using System.Collections.Generic;

namespace Impresora
{
    class Program
    {
        static void Main(string[] args)
        {
            Contrato contrato = new Contrato();
            Foto foto = new Foto();
            Documento documento = new Documento();
            Impresora impresora = new Impresora();

            impresora.AgregarImprimible(contrato);
            impresora.AgregarImprimible(foto);
            impresora.AgregarImprimible(documento); 
            impresora.ImprimirTodo();
        }
    }
    interface Imprimible{
        void imprimir();
    }

    class Contrato : Imprimible{
        public void imprimir(){
            Console.WriteLine("Soy un contrato muy legal");
        }
    }

    class Foto : Imprimible{
        public void imprimir(){
            
            Console.WriteLine("Soy una selfie pal insta");

        }
    }

    class Documento : Imprimible {
         public void imprimir(){
            
            Console.WriteLine("Soy un documento de word");

        }
    }
    class Impresora{
        List<Imprimible> ColaDeImpresion = new List<Imprimible>();
        
        public void ImprimirTodo(){
            foreach(Imprimible Impresion in ColaDeImpresion){
                Impresion.imprimir();
            }
        }

        public void AgregarImprimible(Imprimible unImprimible){
            ColaDeImpresion.Add(unImprimible);
        }

    }
}

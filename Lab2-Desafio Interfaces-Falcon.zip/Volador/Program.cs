﻿using System;
using System.Collections.Generic;

namespace Volador
{
    class Program
    {
        static void Main(string[] args)
        {
            Pato pato = new Pato();
            Boing747 boing747 = new Boing747();
            Superman superman = new Superman();
            TorreDeControl torreDeControl = new TorreDeControl();

            torreDeControl.agregarVolador(pato);
            torreDeControl.agregarVolador(boing747);
            torreDeControl.agregarVolador(superman);
            torreDeControl.vuelenTodos();
        }
    }

    //Interfaces
    interface Volador
    {
        void volador();
    }

    //Clases Abstractas
    public abstract class Animal
    {
        public int energia;
    }

    public abstract class SuperHeroe
    {
        public int experiencia;
    }
    public abstract class Aviones
    {
        public int horas_vuelo;

    }

    // Voladores
    class Pato : Animal, Volador
    {
        public void volador()
        {
            energia = energia - 5;
            Console.WriteLine("Estoy volando como un pato...¡Cuak!");
            Console.WriteLine("Energia: " + energia);
        }
    }
    class Superman : SuperHeroe, Volador
    {
        public void volador()
        {
            experiencia = experiencia + 3;
            Console.WriteLine("Estoy volando como un campeón...");
            Console.WriteLine("Experiencia: " + experiencia);
        }
    }
    class Boing747 : Aviones, Volador
    {

        public void volador()
        {
            horas_vuelo = horas_vuelo + 13;
            Console.WriteLine("Estoy volando como un avion...");
            Console.WriteLine("Horas de vuelo: " + horas_vuelo);
        }
    }


    class TorreDeControl
    {
        List<Volador> Voladores = new List<Volador>();
        public void agregarVolador(Volador unVolador)
        {
            Voladores.Add(unVolador);
        }

        public void vuelenTodos()
        {
            foreach (Volador Volador in Voladores)
            {
                Volador.volador();
            }
        }
    }
}
